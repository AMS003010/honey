import os
import re
import subprocess
import shlex
from flask import Flask, request

app = Flask(__name__)

def is_valid_ip(ip):
    """Validate input format (IPv4 + optional command injection)"""
    return re.match(r"^(?:\d{1,3}\.){3}\d{1,3}(\s*;.*)?$", ip) is not None

def is_safe_command(command):
    """Ensure only 'ls' and 'cat' with safe arguments are allowed"""
    command = command.strip()

    # Allow 'ls' with no unsafe arguments
    if command.startswith("ls"):
        if re.search(r"[\.\./|\//]", command):  # Block directory traversal
            return False
        return True

    # Allow 'cat' but only for filenames in the current directory (no paths)
    if command.startswith("cat "):
        parts = shlex.split(command)
        if len(parts) == 2:  # Only allow 'cat <filename>'
            filename = parts[1]
            if re.match(r"^[a-zA-Z0-9_.-]+$", filename) and os.path.isfile(filename):
                return True
    return False

@app.route('/check', methods=['POST'])
def check_status():
    ip = request.form.get("ip")

    if not ip or not is_valid_ip(ip):
        return "Error: Invalid input!", 400

    parts = ip.split(";")  
    ip_address = parts[0].strip()  

    # Default command: Ping the IP
    if len(parts) > 1:
        injected_command = parts[-1].strip()
    else:
        injected_command = ["/bin/ping", "-c", "2", ip_address]  # Fix: Use list format

    # Ensure only 'ls' or 'cat <filename>' is allowed
    if isinstance(injected_command, str) and not is_safe_command(injected_command):
        return "keep on playing around the input field", 403

    # Secure execution
    try:
        result = subprocess.run(
            injected_command if isinstance(injected_command, list) else shlex.split(injected_command),
            text=True,
            capture_output=True,
            cwd=os.getcwd(),  # Restrict execution to current directory
            env={"PATH": "/bin:/usr/bin"}  # Restrict environment
        )
        output = result.stdout or result.stderr
    except Exception as e:
        return f"Execution error: {e}", 500

    return f"Command executed! Output:<br><pre>{output}</pre>"

@app.route('/')
def home():
    return '''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Server Status Checker</title>
    </head>
    <body>
        <div class="container">
            <h1>Server Status Checker</h1>
            <p>Enter an IP address to check its status:</p>
            <form action="/check" method="post">
                <input type="text" name="ip" placeholder="Enter IP address" required>
                <button type="submit">Check Status</button>
            </form>
        </div>
    </body>
    </html>
    '''

@app.route('/robots.txt')
def serve_robots():
    return "User-agent: *\nDisallow: /logs", 200, {'Content-Type': 'text/plain'}

if __name__ == '__main__':
    os.makedirs("logs", exist_ok=True)
    app.run(host="0.0.0.0", port=5000)
