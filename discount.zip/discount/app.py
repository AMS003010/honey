from flask import Flask, request, jsonify
import random

app = Flask(__name__)



# Sample user database (doesn't explicitly expose 'admin')
users = {
    "9999": {"name": "Alice", "discount": 10, "cart": ["Laptop", "Mouse"]},
    "1000": {"name": "Bob", "discount": 15, "cart": ["Keyboard", "Monitor"]},
    "1000": {"name": "Bob", "discount": 15, "cart": ["Keyboard", "Monitor"]},
    "5578": {"name": "VIP Customer", "discount": 100, "cart": ["Flag", "kalpana2025{in53cur3_dir3c7_0bj3c7_r3f3r3nc3}"]}
}

@app.route("/cart/apply_discount", methods=["GET"])
def apply_discount():
    user_id = request.args.get("user")
    
    # Avoid leaking admin presence by returning a generic response
    if user_id not in users:
        return jsonify({"user": "Unknown", "cart": [], "discount": "0% applied!"})

    return jsonify({
        "user": users[user_id]["name"],
        "cart": users[user_id]["cart"],
        "discount": f"{users[user_id]['discount']}% applied!"
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)
